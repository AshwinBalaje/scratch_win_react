import check from './assets/images/check.png';

function Thanks(props){
    return (
        <section className="thanksPage">
            <img src={check}></img>
            
                
                <div className="thanksBox">
                    <h2 id="thanksTitle">Thanks!</h2>
                    <h2 id="thanksTitle2">Thanks!</h2>
                    <h2 id="setTitle">You are all set</h2>
                    <h2 id="setTitle2">You are all set</h2>
                </div>

            
            <div className="grid-x">
                <div className="large-4 large-offset-4 small-10 small-offset-1 cell confirmationBox">
                    <h2>Form</h2>
                    <p className="boxText">Thanks you for registration {props.fname} {props.lname} {props.address} {props.city} {props.phone} {props.province} {props.email}!  Lets play and win some Prizes.</p>
                    <button type="submit" id="formSubmitBtn" className="btns submitBtn"><p>Continue<span>&#62;</span></p></button>
                </div>
            </div>
            
        </section>
    )
}
export default Thanks;